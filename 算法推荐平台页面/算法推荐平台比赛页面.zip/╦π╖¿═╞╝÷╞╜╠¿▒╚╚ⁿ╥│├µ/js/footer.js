let time = document.querySelector(".time");
	time.innerHTML = new Date();
let run = function() {
	let str = nTime = new Date();
		time.innerHTML = str;
}
setInterval(run,1000);